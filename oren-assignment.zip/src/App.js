import './App.css';
import Fetching from './components/Fetching';

function App() {
  return (
    <div className="App">
      <Fetching/>
    </div>
  );
}

export default App;
